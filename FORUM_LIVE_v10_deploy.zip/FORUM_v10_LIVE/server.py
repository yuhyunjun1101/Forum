#!/usr/bin/env python3
"""FORUM LIVE local server. No third-party Python packages required."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.request import Request, urlopen
from urllib.parse import urlparse
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree as ET
from email.utils import parsedate_to_datetime
import json, os, time, threading, re, html

BASE=Path(__file__).resolve().parent
PORT=int(os.environ.get('PORT','8000'))
NEWS={
 'BBC World':'https://feeds.bbci.co.uk/news/world/rss.xml',
 'BBC Business':'https://feeds.bbci.co.uk/news/business/rss.xml',
 'BBC Technology':'https://feeds.bbci.co.uk/news/technology/rss.xml',
 'The Guardian World':'https://www.theguardian.com/world/rss',
 'The Guardian Environment':'https://www.theguardian.com/environment/rss',
 'DW English':'https://rss.dw.com/xml/rss-en-all',
 'Al Jazeera English':'https://www.aljazeera.com/xml/rss/all.xml',
}
# Public official-channel RSS; videos link to YouTube (no rehosting).
VIDEO={
 'BBC News':'UC16niRr50-MSBwiO3YDb3RA',
 'DW News':'UCknLrEdhRCp1aegoMqRaCZg',
 'Al Jazeera English':'UCNye-wNBqNL5ZzHSJj3l8Bg',
}
PATTERNS={
 'trade':r'\b(trade|tariff|export|import|customs|supply chain|sanction|wto)\b',
 'energy':r'\b(energy|power|electricity|oil|gas|climate|solar|wind|nuclear|renewable|grid)\b',
 'law':r'\b(election|parliament|government|law|regulation|policy|court|president|minister|digital|privacy)\b',
 'chips':r'\b(technology|ai|chip|semiconductor|nvidia|apple|google|computing|software|cyber|data center)\b',
 'diplomacy':r'\b(diplomacy|diplomatic|treaty|summit|alliance|foreign|united nations|talks|negotiation|bilateral)\b',
}
CACHE={'until':0,'value':None}; LOCK=threading.Lock()

def get(url):
 req=Request(url,headers={'User-Agent':'FORUM-LIVE/1.0 (+RSS reader; contact developer)','Accept':'application/rss+xml, application/atom+xml, application/xml, text/xml'})
 with urlopen(req,timeout=7) as res:
  return res.read(2_000_000)

def valid_url(url):
 p=urlparse(url)
 return p.scheme=='https' and bool(p.hostname) and not p.username and not p.password

def parse_rss(data,source):
 root=ET.fromstring(data); out=[]
 for item in root.findall('.//item')[:35]:
  title=html.unescape((item.findtext('title') or '').strip());url=(item.findtext('link') or '').strip()
  if not title or not valid_url(url):continue
  date=(item.findtext('pubDate') or '')
  try: date=parsedate_to_datetime(date).astimezone(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
  except Exception:date=''
  thumb=''
  for el in item:
   if el.tag.endswith('thumbnail') or el.tag.endswith('content'):
    possible=el.attrib.get('url','')
    if valid_url(possible) and possible.lower().split('?')[0].endswith(('.jpg','.jpeg','.png','.webp')):thumb=possible;break
  out.append({'title':title,'url':url,'source':source,'published':date,'thumbnail':thumb})
 return out

def parse_youtube(data,source):
 root=ET.fromstring(data); ns={'a':'http://www.w3.org/2005/Atom','yt':'http://www.youtube.com/xml/schemas/2015'};out=[]
 for entry in root.findall('a:entry',ns)[:20]:
  title=entry.findtext('a:title','',ns).strip();vid=entry.findtext('yt:videoId','',ns).strip();date=entry.findtext('a:published','',ns)[:16].replace('T',' ')
  if not re.fullmatch(r'[A-Za-z0-9_-]{11}',vid):continue
  out.append({'title':title,'url':'https://www.youtube.com/watch?v='+vid,'source':source,'published':date,'thumbnail':'https://i.ytimg.com/vi/'+vid+'/hqdefault.jpg'})
 return out

def refresh():
 with LOCK:
  if CACHE['value'] is not None and time.time()<CACHE['until']:return CACHE['value']
  articles=[];videos=[];errors=[]
  for name,url in NEWS.items():
   try:articles.extend(parse_rss(get(url),name))
   except Exception as exc:errors.append(name+': '+type(exc).__name__)
  for name,channel in VIDEO.items():
   try:videos.extend(parse_youtube(get('https://www.youtube.com/feeds/videos.xml?channel_id='+channel),name))
   except Exception as exc:errors.append(name+': '+type(exc).__name__)
  topics={}
  for tid,pattern in PATTERNS.items():
   rx=re.compile(pattern,re.I)
   topics[tid]={'articles':[x for x in articles if rx.search(x['title'])][:16], 'videos':[x for x in videos if rx.search(x['title'])][:12]}
  value={'topics':topics,'article_count':len(articles),'video_count':len(videos),'updated':datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),'errors':errors}
  CACHE.update(until=time.time()+(900 if articles or videos else 90),value=value)
  return value

class Handler(SimpleHTTPRequestHandler):
 def __init__(self,*a,**kw):super().__init__(*a,directory=str(BASE),**kw)
 def do_GET(self):
  if self.path.split('?')[0]=='/health':
   body=b'{"status":"ok"}'
   self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body);return
  if self.path.split('?')[0]=='/api/feed':
   try:
    body=json.dumps(refresh(),ensure_ascii=False).encode('utf-8')
    self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
   except Exception as exc:
    body=json.dumps({'error':str(exc)}).encode();self.send_response(500);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
   return
  super().do_GET()
if __name__=='__main__':
 print(f'FORUM LIVE listening on 0.0.0.0:{PORT}',flush=True);ThreadingHTTPServer(('0.0.0.0',PORT),Handler).serve_forever()

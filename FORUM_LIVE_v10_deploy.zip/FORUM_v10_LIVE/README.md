# FORUM LIVE v1.0 — 배포용

데모 버전은 포함하지 않습니다. `index.html`은 브라우저 UI, `server.py`는 RSS/영상 피드 수집과 정적 파일 제공을 담당합니다.

## 로컬 실행

Python 3.10+ 환경에서 `python3 server.py` (Windows: `py server.py`)를 실행하고 `http://localhost:8000`에 접속합니다.

- `/health` : 서버 상태 확인
- `/api/feed` : 뉴스/영상 피드와 소스별 오류

## Render 무료 배포 (GitHub 필요)

1. GitHub에서 **새 public 또는 private 저장소**를 만들고 이 폴더의 파일들을 저장소 **최상위 경로**에 업로드합니다.
2. Render (https://dashboard.render.com/)에 로그인합니다.
3. **New > Blueprint**를 선택하고 GitHub 저장소를 연결합니다.
4. Render가 루트의 `render.yaml`을 읽는지 확인합니다. **Apply**하여 배포합니다.
5. 배포 완료 후 Render가 제공하는 `https://...onrender.com` 주소를 엽니다.
6. 같은 도메인의 `/health`와 `/api/feed`로 상태와 수집 결과를 확인합니다.

Blueprint가 보이지 않으면 Render에서 **New > Web Service**를 만들고 저장소를 연결한 뒤 Runtime=Python, Build Command=`echo No dependencies required`, Start Command=`python server.py`, Instance Type=Free로 지정할 수 있습니다.

## 제한사항

- RSS 제공자의 접근 정책, 국가별 제한, 네트워크 오류에 따라 기사/영상이 비어 있을 수 있습니다. `/api/feed`의 `errors`를 확인하세요.
- 현재 홈의 대표 주제와 기본 토론 노드는 예시이며 실제 사건 자동 클러스터링은 구현되지 않았습니다. 실제 기사는 원문 링크만 제공합니다.
- 작성한 댓글/주장은 브라우저 로컬 저장소에만 저장됩니다. 다른 사용자와 공유되지 않습니다.
- Render 무료 인스턴스는 비활성 시 일시정지될 수 있고 요금제 정책은 변경될 수 있습니다.
- 소스 RSS의 제목/링크만 표시하며 기사 전문을 복제하지 않습니다. YouTube 영상은 원본 링크로 이동합니다.
